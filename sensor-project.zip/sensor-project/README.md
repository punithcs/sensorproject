
# Sensor Project

Developed using React Technologies.

`git clone using the repo `

unzip the folder (due to system folder am not able to upload all files into github due to that i have uploaded zip file)

go to sensor-project

`npm install`

It will install the node modules packages inside the sensor project folder which is neccessary to run the project.

`npm start`

so your websit is ready & run it on http://localhost:3000

Thank you.