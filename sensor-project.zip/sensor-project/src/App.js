import React,{useEffect, useState} from "react";
const setArr = ["1111111", "1111111", "1111111", "1111111", "1111111", "0000100", "1101011", "1111000", "1111111"]

const red = {
  'height': '25px',
  'width': '25px',
  'backgroundColor': 'red',
  'borderRadius': '50%',
  'display': 'inline-block',
}

const green = {
  'height': '25px',
  'width': '25px',
  'backgroundColor': 'green',
  'borderRadius': '50%',
  'display': 'inline-block',
}

const yellow = {
  'height': '25px',
  'width': '25px',
  'backgroundColor': 'yellow',
  'borderRadius': '50%',
  'display': 'inline-block',
}
const circle = {
  border: '5px solid black',
  borderRadius: '50%',
  bottom: '100px',
  width: '100px',
  height: '100px',
}
const line = {
  border: '2px solid black',
  width: '0px',
  height: '200px',
  margin:'0 auto'
}
const line1 = {
  border: "2px solid black",
    width: "0px",
    height: "100px",
    margin: "0px auto",
    position: "absolute",
    transform: "rotate(45deg)",
    left: "16px",
    bottom: "-87px",
}
const line2 = {
  border: "2px solid black",
  width: "0px",
  height: "100px",
  margin: "0px auto",
  position: "absolute",
  transform: "rotate(135deg)",
  bottom: "-87px",
  right: "15px",
}
const crossline = {
  border: "2px solid black",
  width: "100px",
  height: "2",
  margin: "20px auto",
  position:"absolute",
}
const crossline1 = {
  border: "2px solid black",
  width: "100px",
  height: "2",
  margin: "20px auto",
  position:"absolute",
  left:"-50px"
}
function App() {
  // console.log(setArr[0] = "000000000");

  const [StringData1, setStringData1] = useState("");
  const stringData = (e)=>{
    if(e.target.name === "string1"){
      setStringData1(e.target.value);
    }
  }
 
  const display = ()=>{
    setArr[0] = StringData1;
    
  }
  return (
    <div>
      <div>
        <label>Bit Strings1</label>
        <input type="text" name="string1" onChange={(e)=>stringData(e)} maxLength="9"/>
      </div>
      <div>
        <label>Bit Strings2</label>
        <input type="text" name="string2" />
      </div>
      <div>
        <label>Bit Strings3</label>
        <input type="text" name="" />
      </div>
      <div>
        <label>Bit Strings4</label>
        <input type="text" name="" />
      </div>
      <input type="submit" onClick={display}/>
      <div className="" style={{position:"relative",width:"110px",margin:"0 auto"}}>
          <div style={circle}></div>
          <div style={line}>
              <div style={crossline}></div>
              <div style={crossline1}></div>
              <div style={line1}></div>
              <div style={line2}></div>
          </div>
      </div>
      <div>
        {
          setArr.map((c, i) => {
            if (c.indexOf('0') < 0 && c.slice(-1) !== '0') {
              return <span style={green} key={i}></span>
            } else if (c.indexOf('0') >= 0 && c.indexOf('1') >= '0' && c.slice(-1) !== '0') {
              return <span style={yellow} key={i}></span>
            } else if (c.slice(-1) === '0') {
              return <span style={red} key={i}></span>
            }
          })
        }
      </div>
    </div >
  );
}


export default App;
